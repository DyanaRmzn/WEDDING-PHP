import sqlite3 as sql

from functools import wraps
from flask import session,flash,redirect,url_for

connect_db ='wedding.db' 


def senarai_wedding():
  with sql.connect(connect_db) as db:
    qry = 'select * from wedding_planner' 
    result=db.execute(qry)
    return(result)

def senarai_booking():
  with sql.connect(connect_db) as db:
    qry = 'select * from booking' 
    result=db.execute(qry)
    return(result)

def senarai_detail():
  with sql.connect(connect_db) as db:
    qry = 'select * from detail' 
    result=db.execute(qry)
    return(result)

#list_stu_sub_grade()

#def list_stu_grade():
  #with sql.connect(connect_db) as db:
    #qry = 'select students.matrixno, students.name, grade.subject_code,grade.marks, grade.grade, grade.grade_point from students, grade where students.matrixno=grade.matrixno' 
    #result=db.execute(qry)
    #return(result)


def result():
  rows=senarai_wedding()
  rows=senarai_booking() 
  rows=senarai_detail()
  for row in rows:
    print (row)
     
# helper function

def login_required(f):
  @wraps(f)
  def wrap(*args, **kwargs):
    if 'logged_in' in session:
        return f(*args, **kwargs)
    else:
        flash("You need to login first")
        return redirect(url_for('home'))
  return wrap

def insert_wedding(custID,custname,custBudget,custPhone,custEmail,password):
  with sql.connect(connect_db) as db:
    qry='insert into wedding_planner (custID,custname,custBudget,custPhone,custEmail,password)values (?,?,?,?,?,?)' 
    db.execute(qry,(custID,custname,custBudget,custPhone,custEmail,password))

def update_wedding(custID,custname,custBudget,custPhone,custEmail,password):
  with sql.connect(connect_db) as db:
    qry='update wedding_planner set custname=?,custBudget=?,custPhone=?,custEmail=?,password=? where custID=?' 
    db.execute(qry,(custname,custBudget,custPhone,custEmail,password,custID))
    
def insert_detail(custID, bookID, foodcost, preparecost, totalcost):
  with sql.connect(connect_db) as db:
    qry='insert into detail (custID, bookID, foodcost, preparecost, totalcost) values (?,?,?,?,?)'
    db.execute(qry,(custID, bookID, foodcost, preparecost, totalcost))

def update_detail(id,custID, bookID, foodcost, preparecost, totalcost):
  with sql.connect(connect_db) as db:
    qry='update detail set custID=?,bookID=?,foodcost=?,preparecost=?,totalcost=? where id=?' 
    db.execute(qry,(custID,bookID,foodcost,preparecost,totalcost,id))
    
def insert_booking(bookID, placename, guest, eventDate, availability):
  with sql.connect(connect_db) as db:
    qry='insert into booking (bookID, placename, guest, eventDate, availability) values (?,?,?,?,?)'
    db.execute(qry,(bookID, placename, guest, eventDate, availability))

def update_booking(bookID, placename, guest, eventDate, availability):
  with sql.connect(connect_db) as db:
    qry='update booking set placename=?,guest=?,eventDate=?,availability=? where bookID=?' 
    db.execute(qry,(placename, guest, eventDate, availability, bookID))

  
def find_wedding(custID):
  with sql.connect(connect_db) as db:
    qry = 'select * from wedding_planner where custID=?'
    result=db.execute(qry,(custID,)).fetchone()
    return(result)

def find_detail(id):
  with sql.connect(connect_db) as db:
    qry = 'select * from detail where id=?'
    result=db.execute(qry,(id,)).fetchone()
    return(result)

def find_booking(bookID):
  with sql.connect(connect_db) as db:
    qry = 'select * from booking where bookID=?'
    result=db.execute(qry,(bookID,)).fetchone()
    return(result)

def check_custID(custID):
  with sql.connect(connect_db) as db: 
    qry = 'select custID,password from wedding_planner where custID=?'
    result=db.execute(qry,(custID,)).fetchone()
    return(result)

def check_id(id):
  with sql.connect(connect_db) as db: 
    qry = 'select id from detail where id=?'
    result=db.execute(qry,(id,)).fetchone()
    return(result)

def check_bookID(bookID):
  with sql.connect(connect_db) as db: 
    qry = 'select bookID from detail where bookID=?'
    result=db.execute(qry,(bookID,)).fetchone()
    return(result)


def delete_wedding(custID):
  with sql.connect(connect_db) as db:
    qry='delete from wedding_planner where custID=?' 
    db.execute(qry,(custID,))

def delete_detail(id):
  with sql.connect(connect_db) as db:
    qry='delete from detail where id=?' 
    db.execute(qry,(id,))

def delete_booking(bookID):
  with sql.connect(connect_db) as db:
    qry='delete from booking where bookID=?' 
    db.execute(qry,(bookID,))
    
def checklogin(username,password):
  with sql.connect(connect_db) as db: 
    qry = 'select username,password from users where username=? and password=?'
    result=db.execute(qry,(username,password)).fetchone()
    return(result)
