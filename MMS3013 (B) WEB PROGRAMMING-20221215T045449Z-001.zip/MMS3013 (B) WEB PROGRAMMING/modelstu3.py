import sqlite3 as sql

from functools import wraps
from flask import session,flash,redirect,url_for

connect_db ='testpekerja.db' 


def pekerja():
  with sql.connect(connect_db) as db:
    qry = 'select * from pekerja' 
    result=db.execute(qry)
    return(result)

def gaji():
  with sql.connect(connect_db) as db:
    qry = 'select * from gaji' 
    result=db.execute(qry)
    return(result)

def senarai_gaji():
  with sql.connect(connect_db) as db:
    qry ='select pekerja.nama, gaji.gaji, gaji.kwsp, gaji.socso, gaji.cukai, gaji.gaji_bersih, gaji.tarikh from pekerja, gaji where pekerja.idpekerja=gaji.idpekerja' 
    result=db.execute(qry)
    return(result)



def result():
  rows=pekerja()
  gaji() 
  for row in rows:
    print (row)
     

def insert_gaji(idpekerja,gaji,kwsp,socso,cukai,gaji_bersih,tarikh):
  with sql.connect(connect_db) as db:
    qry='insert into gaji (idpekerja,gaji,kwsp,socso,cukai,gaji_bersih,tarikh) values (?,?,?,?,?,?,?)' 
    db.execute(qry,(idpekerja,gaji,kwsp,socso,cukai,gaji_bersih,tarikh))
    