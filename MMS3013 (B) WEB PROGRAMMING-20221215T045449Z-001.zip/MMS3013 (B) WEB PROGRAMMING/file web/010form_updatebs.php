<!DOCTYPE html> 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Update Pelajar</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
<?PHP
include ('001link_db2.php'); 
$nomatrik=$_GET['nomatrik'];
$query="SELECT * FROM pelajar WHERE nomatrik='$nomatrik'";
$result=mysqli_query($conn,$query);
$num= mysqli_num_rows($result);

$i=0;
while ($i < $num) {
$show=mysqli_fetch_assoc($result);
$nomatrik=$show['nomatrik'];
$nama=$show['nama'];
$umur=$show['umur'];
//$tarikh_lahir=$show['tarikh_lahir'];
$jantina=$show['jantina'];
$email=$show['email'];
?>
<div class="container">
<form action="011pros_update.php" method="post">
  <div class="form-group">
    <label for="nomatrik">No Matrik:</label>
    <input type="text" class="form-control" name="ud_nomatrik" id="ud_nomatrik" readonly="readonly" value="<?php echo $nomatrik; ?>" />
  </div>
  <div class="form-group">
    <label for="nama">Nama:</label>
    <input type="text" class="form-control" name="ud_nama" id="ud_nama"  value="<?php echo $nama; ?>" />
  </div>
  
  <div class="form-group">
    <label for="umur">Umur:</label>
    <input type="text" class="form-control" name="ud_umur" id="ud_umur"  value="<?php echo $umur; ?>" />
  </div>
  
  <div class="form-group">
    <label for="jantina">Jantina:</label>
    <input type="text" class="form-control" name="ud_jantina" id="ud_jantina"  value="<?php echo $jantina; ?>" />
  </div>
  <div class="form-group">
    <label for="email">Email:</label>
    <input type="text" class="form-control" name="ud_email" id="ud_email"  value="<?php echo $email; ?>" />
  </div>

  <button  name="SUBMIT" type="SUBMIT" class="btn btn-default">SUBMIT</button>
</form>

<?PHP
++$i;
}
?>
</body>
</html>