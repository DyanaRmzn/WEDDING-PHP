<?PHP include ('001link_db2.php'); 
$ud_nomatrik=$_POST['ud_nomatrik'];
$ud_nama=$_POST['ud_nama'];
$ud_umur=$_POST['ud_umur'];
$ud_jantina=$_POST['ud_jantina'];
$ud_email=$_POST['ud_email'];

$query="UPDATE pelajar SET nama='$ud_nama', umur='$ud_umur',jantina='$ud_jantina',email='$ud_email'  
WHERE nomatrik='$ud_nomatrik'";
mysqli_query($conn,$query);
header("location:009editanddelete.php");
mysqli_close($conn);
?>