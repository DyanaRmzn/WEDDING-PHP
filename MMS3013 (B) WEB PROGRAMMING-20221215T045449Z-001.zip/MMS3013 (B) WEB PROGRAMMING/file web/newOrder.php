<html>
<head>
<title>ORDER </title>
<link rel="stylesheet" type="text/css" href="../menu/pro_dropdown_3/pro_dropdown_3.css" />
<link rel="stylesheet" type="text/css" href="style2.css">
<script src="../menu/pro_dropdown_3/stuHover.js" type="text/javascript"></script>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
      	body{    
		 margin:0;
    padding:0;
    background:url(bgnew.jpg);
    background-size: cover;
    font-family:sans-serif; }

		.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}	
.scroll-left {
 height: 50px;	
 overflow: hidden;
 position: relative;
 background: rgba(192,192,192,0.3);
 color: black;

 font-size: x-large;
 
}
.scroll-left p {
 position: absolute;
 width: 100%;
 height: 100%;
 margin: 0;
 line-height: 50px;
 text-align: center;
 
 /* Starting position */
 transform:translateX(100%);
 /* Apply animation to this element */
 animation: scroll-left 15s linear infinite;
}
/* Move it (define the animation) */
@keyframes scroll-left {
 0%   {
 transform: translateX(100%); 		
 }
 100% {
 transform: translateX(-100%); 
 }
}
.container {
		background-color: #000;
		color: black;
		margin-top:80px;
		box-sizing: border-box;
		box-shadow: 8px 8px 50px #000;
		background: rgba(192,192,192,0.3);
		right:20%;
		left:20%; 
		padding: 10px 10px;
		border-radius:15px;
		width: 460px;
        height: 460px;
		position: absolute;
}
/*pagination*/
.center {
		text-align: center;
	}

	.pagination {
		display: inline-block;
		top:0%;
	}

	.pagination a {
		position: center;
		color: black;
		float: left;
		padding: 8px 16px;
		text-decoration: none;
		background-color: #666362;
		border: 1px solid #ddd;
		margin: 0 1px;
	}
.button {
    background-color: #567AF7;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

		</style>
</head>
</head>
<body>
<div class="topnav">
        <a href="frameef.html">HOME</a>
		<a href="fish_details.php">LIST OF FISH</a></u>
		<a class="active" href="new_order_form.php">ORDER FORM</a>  
        <a href="aboutUs.php">ABOUT US</a>
		<a href="logout_ef.php" >LOGOUT</a></u></b></h4>
	</div>
	<div class="scroll-left">
		<p> <img class="fish" src="fish.gif"  alt="fish" >WELCOME TO  EZFISH WEBSITE &nbsp; GET YOUR FRESH FISH NOW!! &emsp;WELCOME TO  EZFISH WEBSITE &nbsp; GET YOUR FRESH FISH NOW!</p>		
		</div>

        <div class="container">
        <h1><b><center>Thank you for your order</center></b></h1>
        <p>(You can pick-up your order at our selected location)</p>
    <br>
		<!-- INSERT GIF -->
		
        &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; <img class="avatar" src="tq.gif"  alt="avatar" style="text-align: center;" >
    
	<style>
        .avatar{
            text-align: center;
}
.fish{
    width:36px;
    height:36px;
}
</style>
<br><br><br>&emsp;
<a href="frameef.html" class="button" style="text-align: center;">Back to Home</a>&emsp;&emsp;&emsp;&emsp;&emsp;
<a href="new_order_form.php" class="button" style="text-align: center;">Order Again</a>
</div>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<div class="pagination">
			<a href="frameef.html">&laquo;</a>
			<a href="fish_details.php">1</a>
			<a href="new_order_form.php">2</a>
			<a href="aboutUs.php">3</a>
			<a href="aboutUs.php">&raquo;</a>
		  </div>	
</body>
</html>
