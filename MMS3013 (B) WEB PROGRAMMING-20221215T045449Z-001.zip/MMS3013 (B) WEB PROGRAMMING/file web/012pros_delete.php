<?PHP
$nomatrik = $_GET['nomatrik'];
include ('001link_db2.php'); 
$query = "delete from pelajar where nomatrik = '$nomatrik'";
$result = mysqli_query($conn,$query);

if ($result==TRUE)
{	echo "record successfully Deleted";
    header("location:009editanddelete.php");
 }
if ($result==FALSE) 
{echo "record unsuccessfully Deleted";
  header("location:009editanddelete.php");}
mysqli_close($conn);
?>