import sqlite3 as sql

from functools import wraps
from flask import session,flash,redirect,url_for

connect_db ='diet.db' 

def list_userdetail():
  with sql.connect(connect_db) as db:
    qry = 'select * from userdetail' 
    result=db.execute(qry)
    return(result)

def list_userintake():
  with sql.connect(connect_db) as db:
    qry = 'select * from userintake' 
    result=db.execute(qry)
    return(result)

def list_dietplan():
  with sql.connect(connect_db) as db:
    qry = 'select * from dietplan' 
    result=db.execute(qry)
    return(result)

#list_stu_sub_grade()
def insert_userintake(meal_id,date,time,food_quantity,food_consumed,drink_quantity,drink_consumed):
  with sql.connect(connect_db) as db:
    qry='insert into userintake (meal_id,date,time,food_quantity,food_consumed,drink_quantity,drink_consumed) values (?,?,?,?,?,?,?)' 
    db.execute(qry,(meal_id,date,time,food_quantity,food_consumed,drink_quantity,drink_consumed))
    
def update_userintake(meal_id,date,time,food_quantity,food_consumed,drink_quantity,drink_consumed):
  with sql.connect(connect_db) as db:
    qry='update userintake set date=?,time=?,food_quantity=?,food_consumed=?, drink_quantity=?, drink_consumed=? where meal_id=?' 
    db.execute(qry, (meal_id,date,time,food_quantity,food_consumed,drink_quantity,drink_consumed))    
    
def insert_userdetail(user_id,name,age,curt_weight, curt_height, bmi, health_condition):
  with sql.connect(connect_db) as db:
    qry='insert into userdetail (user_id,name,age,curt_weight, curt_height, bmi, health_condition) values (?,?,?,?,?,?,?)' 
    db.execute(qry,(user_id,name,age,curt_weight, curt_height, bmi, health_condition))
    
def update_userdetail(user_id,name,age,curt_weight, curt_height, bmi, health_condition):
  with sql.connect(connect_db) as db:
    qry='update userdetail set name=?,age=?,curt_weight=?,curt_height=?,bmi=?,health_condition=? where user_id=?' 
    db.execute(qry, (user_id,name,age,curt_weight, curt_height, bmi, health_condition))   
    
def find_userdetail(user_id):
  with sql.connect(connect_db) as db:
    qry = 'select * from userdetail where user_id=?'
    result=db.execute(qry,(user_id,)).fetchone()
    return(result)

def find_userintake(meal_id):
  with sql.connect(connect_db) as db:
    qry = 'select * from userintake where meal_id=?'
    result=db.execute(qry,(meal_id,)).fetchone()
    return(result)

def find_dietplan(user_id):
  with sql.connect(connect_db) as db:
    qry = 'select * from dietplan where user_id=?'
    result=db.execute(qry,(user_id,)).fetchone()
    return(result)

def check_user_id(user_id):
  with sql.connect(connect_db) as db: 
    qry = 'select user_id from userdetail where user_id=?'
    result=db.execute(qry,(user_id,)).fetchone()
    return(result)

def check_meal_id(meal_id):
  with sql.connect(connect_db) as db: 
    qry = 'select meal_id from userintake where meal_id=?'
    result=db.execute(qry,(meal_id,)).fetchone()
    return(result)

def delete_userdetail(user_id):
  with sql.connect(connect_db) as db:
    qry='delete from userdetail where user_id=?' 
    db.execute(qry,(user_id,))
    
def delete_userintake(meal_id):
  with sql.connect(connect_db) as db:
    qry='delete from userintake where meal_id=?' 
    db.execute(qry,(meal_id,))    

def insert_grade(matrixno,subject_code,marks,grade,grade_point):
  with sql.connect(connect_db) as db:
    qry='insert into grade (matrixno, subject_code, marks, grade, grade_point) values (?,?,?,?,?)' 
    db.execute(qry,(matrixno,subject_code,marks,grade,grade_point))
    
def list_intake_dietplan():
  with sql.connect(connect_db) as db:
    qry = 'SELECT userdetail.user_id, userintake.meal_id, userdetail.name, userintake.date, userintake.time, dietplan.calories_intake, dietplan.food_quantity, dietplan.prescribed_food, dietplan.drink_quantity, dietplan.prescribed_drink from userdetail, userintake, dietplan where userdetail.user_id=dietplan.user_id and userintake.meal_id=dietplan.meal_id ' 
    result=db.execute(qry)
    return(result)

def result():
  rows=list_userdetail()
  rows=list_userintake()
  rows=list_dietplan()
  for row in rows:
    print (row)
    
def checklogin(username,password):
  with sql.connect(connect_db) as db: 
    qry = 'select username,password from users where username=? and password=?'
    result=db.execute(qry,(username,password)).fetchone()
    return(result)    
     
# helper function

def login_required(f):
  @wraps(f)
  def wrap(*args, **kwargs):
    if 'logged_in' in session:
        return f(*args, **kwargs)
    else:
        flash("You need to login first")
        return redirect(url_for('home'))
  return wrap