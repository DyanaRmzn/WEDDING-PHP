<!DOCTYPE html>
<html>
<head>
<title>Registration Form</title>
</head>
<body>
<?php 
include ('001link_db2.php'); 
$nomatrik = $_POST['nomatrik'];
$nama = $_POST['nama'];
$umur = $_POST['umur'];
$jantina = $_POST['jantina'];
$email = $_POST['email'];
$query ="insert into pelajar  values ('$nomatrik','$nama','$umur','$jantina', '$email')";
if (mysqli_query($conn, $query)) {
	//echo "<center><p><img src=\"$target_file\" width=\"190\" height=\"200\"><p>";
  echo "Harga :".$nomatrik."<br>";
  echo "Deposit :".$nama."<br>";
  echo "Tahun :".$umur."<br>";
  echo "Kadar :".$jantina."<br>";
  echo "Bulanan :".$email."<br>";
  
    echo "New record created successfully";
	//echo "<a href=\"003data_tbl.php\">  list</a>"; 
	header("location: 003data_tbl.php");
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?> 
</body>
</html>
