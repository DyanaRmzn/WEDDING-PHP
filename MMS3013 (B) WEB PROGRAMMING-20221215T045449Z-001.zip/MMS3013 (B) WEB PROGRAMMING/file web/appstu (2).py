
#python as a programming language
#flask - web framework
#thonny - IDE
#MVC - model, view, controller

# --- Flask with dynamic variable ---#

# import the Flask class from the flask library

import sqlite3 as sql
#from flask_login import user_loaded_from_header
from modelstu import *
#from user_authentication import *
from flask import Flask,render_template,request,redirect,jsonify

# create the application object
app = Flask(__name__)

#only 3 files - controller, model, view(html files)

@app.route('/list_userdetails', methods=['GET', 'POST', 'DELETE'])
def list_userdetails():
    rows=list_userdetail()
    return render_template('list_userdetail.html', rows=rows)

@app.route('/list_userintakes', methods=['GET', 'POST', 'DELETE'])
def list_userintakes():
    rows=list_userintake()
    return render_template('list_userintake.html', rows=rows)

@app.route('/list_dietplans')
def list_dietplans():
    rows=list_dietplan()
    return render_template('list_dietplan.html', rows=rows)

@app.route('/list_intake_dietplan')
def list_id():
    rows=list_intake_dietplan()
    return render_template('list_intake_dietplan.html', rows=rows)

@app.route('/new')
def new():
    # Make and blank array of five elements
    row=['']*6
    status='0' #insert operation
    return render_template('new_form_userdetail.html',row=row,status=status)


@app.route('/update',methods=['GET','POST','DELETE'])
def insert_update():
    user_id= request.form['user_id']
    name = request.form['name']
    age = request.form['age']
    curt_weight= request.form['curt_weight']
    curt_height = request.form['curt_height']
    bmi = request.form['bmi']
    health_condition = request.form['health_condition']
      
    if request.method=='POST' and request.form['status']=='0':   
        row=['']*7
        row[0] = user_id
        row[1] = name
        row[2] = age
        row[3] = curt_weight
        row[4] = curt_height
        row[5] = bmi
        row[6] = health_condition 
    
        if user_id == '' or  name== '' or age == '' or curt_weight =='' or curt_height =='' or bmi=='' or health_condition== '':
            msg = '';
            if user_id == '':
                msg += 'user_id' if len(msg)==0 else ',user_id'
            if name == '':
                msg += 'name' if len(msg)==0 else ',name'
            if age == '':
                msg += 'age' if len(msg)==0 else ',age'
            if curt_weight == '':
                msg += 'curt_weight' if len(msg)==0 else ',curt_weight'
            if curt_height == '':
                msg += 'curt_height' if len(msg)==0 else ',curt_height'
            if bmi == '':
                msg += 'bmi' if len(msg)==0 else ',bmi'
            if health_condition == '':
                msg += 'health_condition' if len(msg)==0 else ',health_condition'    
            return render_template('new_form_userdetail.html',message=msg,status='0',row=row)
        else:
            if check_user_id(user_id):
                row[0] = ''
                flash('User ID already exist!')                
                return render_template('new_form_userdetail.html',message='user_id '+user_id+' already exist!',status='0',row=row)

            else:        
                insert_userdetail(user_id,name,age,curt_weight, curt_height, bmi, health_condition)        
                return redirect('/list_userdetails') 
             
          
    if request.method=="POST" and request.form['status']=='1':
        update_userdetail(name,age,curt_weight, curt_height, bmi, health_condition, user_id)
        return redirect('/list_userdetails')
    
#new data table grade
@app.route('/new_userintake')
def newg():
    # Make and blank array of six elements
    row=['']*7
    status='0'
    return render_template('new_form_userintake.html',row=row,status=status)

@app.route('/update_intake', methods=['GET','POST','DELETE'])
def insert_updates():
    meal_id = request.form['meal_id']
    date = request.form['date']
    time = request.form['time']
    food_quantity = request.form['food_quantity']
    food_consumed = request.form['food_consumed']
    drink_quantity = request.form['drink_quantity']
    drink_consumed = request.form['drink_consumed']
      
    if request.method=='POST' and request.form['status']=='0':   
        row=['']*7
        row[0] = meal_id
        row[1] = date
        row[2] = time
        row[3] = food_quantity
        row[4] = food_consumed
        row[5] = drink_quantity
        row[6] = drink_consumed 
    
        if meal_id == '' or  date== '' or time == '' or food_quantity =='' or food_consumed =='' or drink_quantity=='' or drink_consumed== '':
            msg = '';
            if meal_id == '':
                msg += 'meal_id' if len(msg)==0 else ',meal_id'
            if date == '':
                msg += 'date' if len(msg)==0 else ',date'
            if time == '':
                msg += 'time' if len(msg)==0 else ',time'    
            if food_quantity == '':
                msg += 'food_quantity' if len(msg)==0 else ',food_quantity'
            if food_consumed == '':
                msg += 'food_consumed' if len(msg)==0 else ',food_consumed'
            if drink_quantity == '':
                msg += 'drink_quantity' if len(msg)==0 else ',drink_quantity'
            if drink_consumed == '':
                msg += 'drink_consumed' if len(msg)==0 else ', drink_consumed'
            return render_template('new_form_userintake.html',message=msg,status='0',row=row)
        else:
            if check_meal_id(meal_id):
                row[0] = ''
                flash('Meal ID already exist!')                
                return render_template('new_form_userintake.html',message='meal_id '+meal_id+' already exist!',status='0',row=row)

            else:        
                insert_userintake(meal_id,date,time,food_quantity,food_consumed,drink_quantity,drink_consumed)        
                return redirect('/list_userintakes') 
             
          
    if request.method=="POST" and request.form['status']=='1':
        update_userintake(date,time,food_quantity,food_consumed,drink_quantity,drink_consumed,meal_id)
        return redirect('/list_userintakes')

@app.route('/edit/<user_id>')
def edit(user_id): 
    row=find_userdetail(user_id)
    status='1'
    return render_template('new_form_userdetail.html',row=row,status=status)

@app.route('/delete/<user_id>')
def delete(user_id):  
     delete_userdetail(user_id)
     return redirect('/list_userdetails')
    
@app.route('/delete_ut/<meal_id>')
def delete_intake(meal_id):  
     delete_userintake(meal_id)
     return redirect('/list_userintakes')    

@app.route('/find_userdetail',methods=['GET','POST'])
def find():
    if request.method=="POST":
        user_id=request.form['user_id']
        row=find_userdetail(user_id)
        return render_template('form2.html',row=row)
    else:   
        return render_template('form1.html')

@app.route('/find_dietplan',methods=['GET','POST'])
def find_dietplan():
    if request.method=="POST":
        user_id=request.form['user_id']
        row=find_userdetail(user_id)
        return render_template('form2.html',row=row)
    else:   
        return render_template('form1.html')

@app.route('/inupdategred',methods=['GET','POST'])
def  insert_updateg():
    id = None
    if 'id' in request.files:
        id = request.form['id']
    matrixno = request.form['matrixno']
    subject_code = request.form['subject_code']
    marks=request.form['marks']
    grade=request.form['grade']
    grade_point=request.form['grade_point']
    
    if request.method=='POST' and request.form['status']=='0':                            
                
        insert_grade(matrixno,subject_code,marks,grade,grade_point)        
        return redirect('/list_stu_grade')  
    
    #if request.method=="POST" and request.form['status']=='1':
        
        #update_grade(id,nomatrik,kod_subjek,markah,gred,mata_nilai)
        #return redirect('/list_grade')

@app.route('/')
def home():
    if not session.get('logged_in'):
        return render_template('loginnew.html')
    else:
        return render_template('home.html')
 
@app.route('/login', methods=['POST'])
def dologin():
    if checklogin(request.form['username'],request.form['password']):
        session['logged_in'] = True
        return render_template('home.html')
    else:
        flash('wrong password!')
        return render_template('loginnew.html',message='Invalid Username or Password!')
        # return redirect('/')

@app.route('/logout')
def logout():
    session['logged_in'] = False
    return home()

@app.route('/admin')
def admin():
    return render_template('base1.html')

#@app.route('/test')
#def test():
    #return "Testing"

#@app.route('/welcome')
#def welcome():
    #return render_template('test.html') 


# start the server using the run() method
if __name__ == "__main__":
     app.secret_key = "!mzo53678912489"
     app.run(debug=True,host='0.0.0.0', port=5000)
