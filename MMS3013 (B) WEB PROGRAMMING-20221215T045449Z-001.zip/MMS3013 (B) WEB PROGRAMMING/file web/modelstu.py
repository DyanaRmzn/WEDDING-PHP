import sqlite3 as sql

from functools import wraps
from flask import session,flash,redirect,url_for

connect_db ='smp2.db' 


def list_student():
  with sql.connect(connect_db) as db:
    qry = 'select * from students' 
    result=db.execute(qry)
    return(result)

def list_subject():
  with sql.connect(connect_db) as db:
    qry = 'select * from subjects' 
    result=db.execute(qry)
    return(result)

#list_stu_sub_grade()



def result():
  rows=list_student()
  list_subject() 
  for row in rows:
    print (row)
     

# helper function

def login_required(f):
  @wraps(f)
  def wrap(*args, **kwargs):
    if 'logged_in' in session:
        return f(*args, **kwargs)
    else:
        flash("You need to login first")
        return redirect(url_for('home'))
  return wrap