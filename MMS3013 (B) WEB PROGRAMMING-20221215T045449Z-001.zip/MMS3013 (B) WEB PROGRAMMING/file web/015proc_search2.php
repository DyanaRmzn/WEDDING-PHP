<html>
<head>
 <title> Search Result </title>
 </head>
<body>

<center>
<h1> Search Result </h1>
</center>
<?php

$searchtype=$_POST['searchtype'];
$searchterm=$_POST['searchterm'];
$searchterm= trim($searchterm);

if (!$searchtype || !$searchterm)
{
	echo ' Please Enter your search. Please enter again.';
	exit;
}

include ('001link_db2.php');
$query = "select * from v_gred where ".$searchtype." like '%".$searchterm."%'";
$result = mysqli_query($conn,$query);
$num_results = mysqli_num_rows($result);
echo "<center>";
echo '<p>Bilangan yang dijumpai: '.$num_results.'</p>';

?>
<P><strong><center> Student List</strong></center>  
<table border="1" width="849" align="center" cellspacing="2" cellpadding="2">
<tr>
<td align="center" bgcolor="#FFCC00"><strong> No Matrik</strong></td>
<td align="center" bgcolor="#FFCC00"><strong>Nama Pelajar</strong></td>
<td align="center" bgcolor="#FFCC00"><strong>ID Subjek</strong></td>
<td align="center" bgcolor="#FFCC00"><strong>Nama Subjek</strong></td>
<td align="center" bgcolor="#FFCC00"><strong>Markah</strong></td>
<td align="center" bgcolor="#FFCC00"><strong>Gred</strong></td> 
<td align="center" bgcolor="#FFCC00"><strong>Mata Nilai</strong></td> 

</tr>
<?PHP

for ($i=0; $i <$num_results; $i++)
{
 $row = mysqli_fetch_array($result);
 echo "<tr>";
 echo "<td>" .$row["nomatrik"]. "</td>";
 echo "<td>" .$row["nama"].  "</td>";
 echo "<td>" .$row["id_subjek"]."</td>";
 echo "<td>" .$row["nama_subjek"]."</td>";
 echo "<td>" .$row["markah"]."</td>";
 echo "<td>" .$row["gred"]."</td>";
 echo "<td>" .$row["mata_nilai"]."</td>";
}
echo "</table>";
echo "<center>";
echo "<br>";
 

 ?>
</body>
</html>
