<html>
<head>
	<title>  Search </title>
 
</head>
<link rel="stylesheet" media="screen" href = "/static/css/bootstrap.min.css">
<body>

<h1 align="center"> Searching </h1>

<form  action="015proc_search2.php" method="post" >
  <div align="center"><span class="style1">Search for</span>:<br/>
    <Select NAME="searchtype">
         <Option VALUE="nomatrik">No Matrik</option>
         <Option VALUE="nama">Nama Pelajar</option>
         <Option VALUE="id_subjek"> ID Subjek</option>
		 <Option VALUE="nama_subjek"> Nama Subjek</option>
         <Option VALUE="markah">Markah</option>
        <Option VALUE="gred">Gred</option>
       <Option VALUE="mata_nilai">Mata Nilai</option>
        
    </Select>
    <br />
Enter Search Term:<br />
<input name="searchterm" type="text" >
<br />

<input type="submit" name="search" value="Search" >
  </div>
</form>
</body>
</html>
