<html>
<head>
<title>Booking Information </title>
<link rel="stylesheet" type="text/css" href="../menu/pro_dropdown_3/pro_dropdown_3.css" />
<script src="../menu/pro_dropdown_3/stuHover.js" type="text/javascript"></script>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   
</head>
</head>
<body style="background-color:#b36f3e;">
<?PHP
//include ('../menu/main_menu.php'); 
include ('001link_db2.php'); 
$sql="SELECT * from booking ORDER BY bookID ASC";
$result = mysqli_query($conn,$sql) or die(mysql_error());

?>
<div class="container">
<P><h1><center style="font-family:arial black; font-weight:bold; color:black">BOOKING INFORMATION </h1></center> <br> 
<style>
table {
  width:100%;
}
table, th, td {
  border: 2px solid black;
  border-collapse: collapse;
  background-color: #dbd2cc;
  font-family:times new roman; 
  
}
th, td {
  padding: 15px;
  text-align: center;
  background-color: white;

} </style>
<table class="table table-hover" border="0" width="849" align="center" cellspacing="2" cellpadding="2">
  <thead>
<tr>
<td align="center" bgcolor="#FFCC00"><strong>Book ID</strong></td>
<td align="center" bgcolor="#FFCC00"><strong>Food cost</strong></td> 
<td align="center" bgcolor="#FFCC00"><strong>Prepare cost</strong></td> 
<td align="center" bgcolor="#FFCC00"><strong>place name</strong></td>
<td align="center" bgcolor="#FFCC00"><strong>Guest</strong></td>
</tr>
 </thead>
<?PHP
while ($row=mysqli_fetch_array($result))
{
 echo "<tr>";
 echo "<td>" .$row["bookID"]. "</td>";
 echo "<td>" .$row["foodcost"]. "</td>";
 echo "<td>" .$row["preparecost"]."</td>";
 echo "<td>" .$row["placename"]."</td>";
 echo "<td>" .$row["guest"]."</td>";

}
echo "</table>";
echo "<center>";
echo "<br>";
echo "</div>";
?>

<ul class="pagination">
  <li class="page-item"><a class="page-link" href="data_wedding_planner.php">Wedding Planner</a></li>
  <li class="page-item active"><a class="page-link" href="data_booking.php">Booking</a></li>
  <li class="page-item"><a class="page-link" href="data_detail.php">Detail</a></li>
  </ul>
  
  
  
  <center>
    <a name="SUBMIT" type="SUBMIT" href="welcome_admin.php"  class="btn btn-default">BACK </a> 
	</center>
<br>
<br>
  
</body>
</html>
