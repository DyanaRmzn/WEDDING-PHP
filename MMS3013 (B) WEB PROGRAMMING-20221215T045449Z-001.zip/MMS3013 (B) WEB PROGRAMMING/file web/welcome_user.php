<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome Page</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">    
</head>
<body>
    <header>
    <div class="wrapper">
        <div class="logo">
            <img src="lo.png" alt="logo" style="width:150px;height:15s0px;">
        </div>
<ul class="nav-area">
<br>
<li><a href="register.php" TARGET="RightFrame">Register</a></li>
<li><a href="logout.php" TARGET="RightFrame" >Log Out</a></li>
</ul>
</div>
<div class="welcome-text">
        <h1>
 <h1 class="my-5">Hi <b><?php echo htmlspecialchars($_SESSION["username"]); ?><span></b>! <h1 style="color:white">WEDDING PLANNER </span></h1>

<p style="color:white"; > PLANNING FOR BETTER FUTURE </p>
    

    </div>
</header>

</body>
</html>