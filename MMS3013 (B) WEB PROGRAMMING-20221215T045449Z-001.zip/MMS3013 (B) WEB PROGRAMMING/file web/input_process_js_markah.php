<!DOCTYPE html>
<html>
<head>
<title>Registration Form</title>
</head>
<body>
<?php 
include ('001link_db2.php'); 
$nomatrik = $_POST['nomatrik'];
$id_subjek = $_POST['id_subjek'];
$markah = $_POST['markah'];
$gred = $_POST['gred'];
$mata_nilai = $_POST['mata_nilai'];
$query ="insert into gred (nomatrik,id_subjek, markah, gred, mata_nilai)
values('$nomatrik','$id_subjek','$markah', '$gred', '$mata_nilai')";
if (mysqli_query($conn, $query)) {
	   
	header("location: 003data_gred.php");
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?> 
</body>
</html>
