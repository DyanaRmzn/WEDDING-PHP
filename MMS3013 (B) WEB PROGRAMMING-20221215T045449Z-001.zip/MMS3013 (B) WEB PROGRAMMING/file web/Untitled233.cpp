//group assignment

#include<iostream>
#include<iomanip>
#include<string>
using namespace std;

void displayMenu(); //function prototype for displayMenu
void printSubtotal(char code, char vehicle, char package, double price, double discount, double totaldis, double subtotal, double total); //function prototype for printSubtotal

int main()
{
	char resp, cod, veh, pack;
	string name, telnum;
	double price, dis, totaldis, subtotal, total=0;
	int num_cust=0;
	
	cout<<fixed<<showpoint; //decimal places up to 2
	cout<<setprecision(2);
	
	do {
        
        displayMenu(); //function call
        
		cout<<"ENTER A CUSTOMER'S NAME : ";
		cin>>name;
		cout<<"ENTER A CUSTOMER'S NUMBER : ";
		cin>>telnum;
		cout<<"ENTER THE TYPE OF VEHICLE (M/C/V) : ";
		cin>>veh;
		cout<<"ENTER THE PACKAGE (A/B/C) : ";
		cin>>pack;
		cout<<"ENTER THE CODE MEMBER (M/N) : ";
		cin>>cod;
		cout<<endl;

	
	printSubtotal(cod, veh, pack, price, dis, totaldis, subtotal, total);
	
	cout<<"**************************************************************"<<endl;
	cout<<"NAME                 : "<<name<<endl;
	cout<<"TELEPHONE NUMBER     : "<<telnum<<endl;
	cout<<"TYPE OF VEHICLE      : "<<veh<<endl;
	cout<<"TYPE OF PACKAGE      : "<<pack<<endl;
	cout<<"CODE MEMBER          : "<<cod<<endl;
	cout<<"PRICE                : RM "<<price<<endl;
	cout<<"TOTAL DISCOUNT       : RM "<<totaldis<<endl;
	cout<<"SUBTOTAL             : RM "<<subtotal<<endl;
	cout<<endl;

	cout<<"Next Custommer (Y/N) : "; //choose whether continue for next customer or not
	cin>>resp;
	
	
	
    } while (resp == 'Y'); 
    
    num_cust = num_cust+1; //number of customer per day
	
    cout<<"NUMBER OF CUSTOMER PER DAY : "<<num_cust<<endl; //display number for customer per day
    cout<<"TOTAL SALE PER DAY : RM"<<total<<endl; //display the total sale
      
	return 0;	
} //end main

//void function
void displayMenu()
{
		cout<<"                          MENU                     "<<endl;
		cout<<"---------------------------------------------------"<<endl;
		cout<<"|      DETAILS      |    PACKAGE    |    PRICE    |"<<endl;
		cout<<"---------------------------------------------------"<<endl;
		cout<<"|                   |   PAKCAGE (A) |   RM 5.00   |"<<endl;
		cout<<"|  MOTORCYCLE (M)   |   PAKCAGE (B) |   RM 10.00  |"<<endl;
		cout<<"|                   |   PACKAGE (C) |   RM 15.00  |"<<endl;
		cout<<"---------------------------------------------------"<<endl;
		cout<<"|                   |   PAKCAGE (A) |   RM 10.00  |"<<endl;
		cout<<"|  COMPACT CAR (C)  |   PAKCAGE (B) |   RM 20.00  |"<<endl;
		cout<<"|                   |   PACKAGE (C) |   RM 25.00  |"<<endl;
		cout<<"---------------------------------------------------"<<endl;
		cout<<"|                   |   PAKCAGE (A) |   RM 15.00  |"<<endl;
		cout<<"|    SUV/VAN (V)    |   PAKCAGE (B) |   RM 25.00  |"<<endl;
		cout<<"|                   |   PACKAGE (C) |   RM 30.00  |"<<endl;
		cout<<"---------------------------------------------------"<<endl;
		cout<<"|   PACKAGE (A) - WASH AND VACCUME                |"<<endl;
		cout<<"|   PACKAGE (B) - WASH, VACCUME AND DRY           |"<<endl;
		cout<<"|   PACKAGE (C) - WASH, VACCUME, DRY AND POLISH   |"<<endl;
		cout<<"|   DISCOUNT 15% ARE ABLE FOR MEMBER ONLY !!      |"<<endl;
		cout<<"---------------------------------------------------"<<endl;
		cout<<endl;
}

void printSubtotal(char code, char vehicle, char package, double price, double discount, double totaldis, double subtotal, double total)
{
	if (code == 'M' || code == 'm') //choose for member
	{
		if (vehicle == 'M') 
		{
			if (package == 'A')
				price = 5.00;
				   
			else if (package == 'B')
				price = 10.00;
				   
			else
				price = 15.00;
		}
		else if (vehicle == 'C')
		{
			if (package == 'A')
				price = 10.00;
				   
			else if (package == 'B')
				price = 20.00;
				   
			else
				price = 25.00;
		}
		else if (vehicle == 'V')
		{
			if (package == 'A')
				price = 15.00;
				   
			else if (package == 'B')
				price = 25.00;
				   
			else
				price = 30.00;
		}
		else
			cout<<"INVALID DATA "<<endl;
			
			
		//calculate the subtotal after minus the discount   
		discount = 0.15;
		totaldis = discount*price;
		subtotal = price - totaldis;
		
	}
    else if (code == 'N' || code == 'n') //choose for non-member
    {
		if (vehicle == 'M')
		{
			if (package == 'A')
				price = 5.00;
				   
			else if (package == 'B')
				price = 10.00;
				   
			else
				price = 15.00;
		}
		else if (vehicle == 'C')
		{
			if (package == 'A')
				price = 10.00;
				   
			else if (package == 'B')
				price = 20.00;
				   
			else
				price = 25.00;
		}
		else if (vehicle == 'V')
		{
			if (package == 'A')
				price = 15.00;
				   
			else if (package == 'B')
				price = 25.00;
				   
			else
				price = 30.00;
		}
		else
			cout<<"INVALID DATA "<<endl;
			   
		discount = 0.00;
		totaldis = discount*price;
		subtotal = price-totaldis;
		total = total + subtotal; //total sale for a day	
	}
	else
	    cout<<"INVALID INPUT"<<endl;
	    cout<<"subtotal is "<<subtotal<<endl;

}
