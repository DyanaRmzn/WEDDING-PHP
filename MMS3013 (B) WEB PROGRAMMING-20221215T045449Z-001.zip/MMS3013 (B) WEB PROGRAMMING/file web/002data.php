<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Buku Javascript dan PHP</title>
</head>

<body>

<?PHP
include ('001link_db2.php'); 
$sql="SELECT * from pelajar ORDER BY nama ASC";
$result =mysqli_query($conn,$sql) or die(mysql_error());
while ($row=mysqli_fetch_array($result))
{
 echo "<br>";
 echo "<td>  " .$row["nomatrik"]. "</td>";
 echo "<td>  " .$row["nama"].  "</td>";
 echo "<td>  " .$row["umur"]."</td>";
 //echo "<td>  " .$row["dob"]."</td>";
 echo "<td>  " .$row["jantina"]."</td>";
echo "<td>  " .$row["email"]."</td>";
}
echo "<br>";
?>
</body>
</html>

</body>
</html>