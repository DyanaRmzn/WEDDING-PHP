#python as a programming language
#flask - web framework
#thonny - IDE
#MVC - model, view, controller

# --- Flask with dynamic variable ---#

# import the Flask class from the flask library

import sqlite3 as sql
#from flask_login import user_loaded_from_header
from modelstu3 import*
#from user_authentication import *
from flask import Flask,render_template,request,redirect,jsonify

# create the application object
app = Flask(__name__)

#only 3 files - controller, model, view(html files)

@app.route('/')
def home():
   return render_template('base3.html') 

@app.route('/gaji')
def gaji():
    rows = gaji()
    return render_template('gaji.html', rows=rows)

@app.route('/pekerja')
def pekerja():
    rows = pekerja()
    return render_template('pekerja.html', rows=rows)

@app.route('/senarai_gaji')
def senarai_gaji():
    rows = senarai_gaji()
    return render_template('senarai_gaji.html', rows=rows)

#new data table gaji
@app.route('/new_gaji')
def newg():
    # Make and blank array of 6 elements
    row=['']*7
    status='0'
    gaji=senarai_gaji()
    return render_template('form_gaji.html',row=row,status=status,gaji=gaji)

@app.route('/inupdategaji',methods=['GET','POST'])
def  insert_updateg():
    id = None
    if 'id' in request.files:
        id = request.form['id']
    idpekerja = request.form['idpekerja']
    gaji = request.form['gaji']
    kwsp =request.form['kwsp']
    socso=request.form['socso']
    cukai=request.form['cukai']
    gaji_bersih=request.form['gaji_bersih']
    tarikh=request.form['tarikh']
    
    if request.method=='POST' and request.form['status']=='0':                            
                
        insert_gaji(idpekerja,gaji,kwsp,socso,cukai,gaji_bersih,tarikh)        
        return redirect('/senarai_gaji')  


# start the server using the run() method
if __name__ == "__main__":
     app.secret_key = "!mzo53678912489"
     app.run(debug=True,host='0.0.0.0', port=5000)

