import sqlite3 as sql

from functools import wraps
from flask import session,flash,redirect,url_for

connect_db ='wedding.db' 


def list_wedding():
  with sql.connect(connect_db) as db:
    qry = 'select * from wedding_planner' 
    result=db.execute(qry)
    return(result)

def list_booking():
  with sql.connect(connect_db) as db:
    qry = 'select * from booking' 
    result=db.execute(qry)
    return(result)

def list_detail():
  with sql.connect(connect_db) as db:
    qry = 'select * from detail' 
    result=db.execute(qry)
    return(result)

#list_stu_sub_grade()

#def list_stu_grade():
  #with sql.connect(connect_db) as db:
    #qry = 'select students.matrixno, students.name, grade.subject_code,grade.marks, grade.grade, grade.grade_point from students, grade where students.matrixno=grade.matrixno' 
    #result=db.execute(qry)
    #return(result)


def result():
  rows=list_wedding()
  list_booking() 
  list_detail()
  for row in rows:
    print (row)
     
# helper function

def login_required(f):
  @wraps(f)
  def wrap(*args, **kwargs):
    if 'logged_in' in session:
        return f(*args, **kwargs)
    else:
        flash("You need to login first")
        return redirect(url_for('home'))
  return wrap

def insert_wedding(custID,custname,custBudget,eventDate,custPhone, custEmail,password):
  with sql.connect(connect_db) as db:
    qry='insert into wedding_planner (custID,custname,custBudget,eventDate,custPhone, custEmail,password)values (?,?,?,?,?)' 
    db.execute(qry,(custID,custname,custBudget,eventDate,custPhone, custEmail,password))
    
def update_wedding(custname,custBudget,eventDate,custPhone, custEmail,password):
  with sql.connect(connect_db) as db:
    qry='update wedding_planner set custname=?,custBudget=?,eventDate=?,custPhone=?,custEmail=?,password=? where custID=?' 
    db.execute(qry, (custname,custBudget,eventDate,custPhone, custEmail,password))
    
def find_wedding(custID):
  with sql.connect(connect_db) as db:
    qry = 'select * from wedding_planner where custID=?'
    result=db.execute(qry,(custID,)).fetchone()
    return(result)

def check_custID(custID):
  with sql.connect(connect_db) as db: 
    qry = 'select custID,password from wedding_planner where custID=?'
    result=db.execute(qry,(custID,)).fetchone()
    return(result)

def delete_wedding_planner(custID):
  with sql.connect(connect_db) as db:
    qry='delete from wedding_planner where custID=?' 
    db.execute(qry,(custID,))

def insert_booking(bookID, foodcost, preparecost, placename, guest):
  with sql.connect(connect_db) as db:
    qry='insert into booking (bookID, foodcost, preparecost, placename, guest) values (?,?,?,?,?)' 
    db.execute(qry,(bookID, foodcost, preparecost, placename, guest))
    
def checklogin(custID,password):
  with sql.connect(connect_db) as db: 
    qry = 'select custID,password from wedding_planner where custID=? and password=?'
    result=db.execute(qry,(custID,password)).fetchone()
    return(result)
