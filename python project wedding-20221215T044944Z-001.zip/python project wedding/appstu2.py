#python as a programming language
#flask - web framework
#thonny - IDE
#MVC - model, view, controller

# --- Flask with dynamic variable ---#

# import the Flask class from the flask library

import sqlite3 as sql
#from flask_login import user_loaded_from_header
from modelstu import*
#from user_authentication import *
from flask import Flask,render_template,request,redirect,jsonify

# create the application object
app = Flask(__name__)

#only 3 files - controller, model, view(html files)

#@app.route('/')
#def home():
    #return "hello world"

@app.route('/test')
def test():
    return "Testing 123"

@app.route('/welcome')
def welcome():
    return render_template('test.html')

@app.route('/list_wedding')
def list_wedding():
    rows = senarai_wedding()
    return render_template('list_wedding.html', rows=rows)

@app.route('/list_booking')
def list_booking():
    rows = senarai_booking()
    return render_template('list_booking.html', rows=rows)

@app.route('/list_detail')
def list_detail():
    rows = senarai_detail()
    return render_template('list_detail.html', rows=rows)


#@app.route('/list_stu_grade')
#def list_sg():
    #rows = list_stu_grade()
    #return render_template('list_student_grade.html', rows=rows)

@app.route('/new')
def new():
    # Make and blank array of seven elements
    row=['']*6
    status='0' #insert operation
    return render_template('form_wedding.html',row=row,status=status)

@app.route('/update',methods=['GET','POST'])
def insert_update():
    custID = request.form['custID']
    custname = request.form['custname']
    custBudget = request.form['custBudget']
    custPhone = request.form['custPhone']
    custEmail=request.form['custEmail']
    password = request.form['password']
      
    if request.method=='POST' and request.form['status']=='0':                            
        row=['']*6
        row[0] = custID
        row[1] = custname
        row[2] = custBudget
        row[3] = custPhone
        row[4] = custEmail
        row[5] = password
        if custID == '' or custname == '' or password == '':
            msg = '';
            if custID == '':
                msg += 'Customer ID' if len(msg)==0 else ',Customer ID'
            if name == '':
                msg += 'Customer name' if len(msg)==0 else ',Customer name'
            if password == '':
                msg += 'Password' if len(msg)==0 else ',Password'
            msg = msg + ' cannot be empty!';
            return render_template('form_wedding.html',message=msg,status='0',row=row)
        else:
            if check_custID(custID):
                row[0] = ''
                flash('Cust ID already exist!')                
                return render_template('form_wedding.html',message='Customer ID '+custID+' already exist!',status='0',row=row)

            else:        
                insert_wedding(custID,custname,custBudget,custPhone,custEmail,password)        
                return redirect('/list_wedding') 
             
          
    if request.method=="POST" and request.form['status']=='1':
        update_wedding(custID,custname,custBudget,custPhone,custEmail,password)
        return redirect('/list_wedding')
    
@app.route('/edit/<custID>')
def edit(custID): 
    row=find_wedding(custID)
    status='1'
    return render_template('form_wedding.html',row=row,status=status)

@app.route('/edit_detail/<id>')
def edit_detail(id): 
    row=find_detail(id)
    status='1'
    return render_template('form_totalcost.html',row=row,status=status)

@app.route('/editb/<bookID>')
def edit_booking(bookID): 
    row=find_booking(bookID)
    status='1'
    return render_template('form_booking.html',row=row,status=status)

@app.route('/delete/<custID>')
def delete(custID):  
     delete_wedding(custID)
     return redirect('/list_wedding')
    
@app.route('/delete_detail/<id>')
def deletedetail(id):  
     delete_detail(id)
     return redirect('/list_detail')

@app.route('/deleteb/<bookID>')
def deleteb(bookID):  
     delete_booking(bookID)
     return redirect('/list_booking')
    
@app.route('/find_wedding',methods=['GET','POST'])
def find():
    if request.method=="POST":
        custID=request.form['custID']
        row=find_wedding(custID)
        return render_template('form2wed.html',row=row)
    else:   
        return render_template('form1wed.html')

@app.route('/find_detail',methods=['GET','POST'])
def finddetail():
    if request.method=="POST":
        id=request.form['id']
        row=find_detail(id)
        return render_template('form2wed.html',row=row)
    else:   
        return render_template('form1wed.html')

@app.route('/findb',methods=['GET','POST'])
def findb():
    if request.method=="POST":
        id=request.form['bookID']
        row=find_booking(id)
        return render_template('form2wed.html',row=row)
    else:   
        return render_template('form1wed.html')
    
    
#new data table detail
@app.route('/new_totalcost')
def newt():
    # Make and blank array of five elements
    row=['']*6
    status='0'
    wedding=list_wedding()
    booking=list_booking()
    return render_template('form_totalcost.html',row=row,status=status,wedding=wedding,booking=booking)

@app.route('/inupdatetotalcost',methods=['GET','POST'])
def  insert_updatet():
    id = None
    if 'id' in request.files:
        id = request.form['id']
    custID = request.form['custID']
    bookID = request.form['bookID']
    foodcost = request.form['foodcost']
    preparecost = request.form['preparecost']
    totalcost = request.form['totalcost']
    
    if request.method=='POST' and request.form['status']=='0':                            
        row=['']*6
        row[0] = id
        row[1] = custID
        row[2] = bookID
        row[3] = foodcost
        row[4] = preparecost
        row[5] = totalcost
        if id == '' or custID == '' or bookID == '':
            msg = '';
            if id == '':
                msg += 'id' if len(msg)==0 else ',id'
            if name == '':
                msg += 'Customer ID' if len(msg)==0 else ',Customer ID'
            if password == '':
                msg += 'Book ID' if len(msg)==0 else ',Book ID'
            msg = msg + ' cannot be empty!';
            return render_template('form_totalcost.html',message=msg,status='0',row=row)
        else:
            if check_id(id):
                row[0] = ''
                flash('id already exist!')                
                return render_template('form_totalcost.html',message='ID '+id+' already exist!',status='0',row=row)

            else:        
                insert_detail(custID, bookID, foodcost, preparecost, totalcost)        
                return redirect('/list_detail') 
             
          
    if request.method=="POST" and request.form['status']=='1':
        update_detail(id, custID, bookID, foodcost, preparecost, totalcost)
        return redirect('/list_detail')

#new data table booking
@app.route('/new_booking')
def newb():
    # Make and blank array of five elements
    row=['']*5
    status='0'
    return render_template('form_booking.html',row=row,status=status)

@app.route('/inupdatebooking',methods=['GET','POST'])
def  insert_updateb():
    bookID = request.form['bookID']
    placename = request.form['placename']
    guest = request.form['guest']
    eventDate = request.form['eventDate']
    availability = request.form['availability']
    
    if request.method=='POST' and request.form['status']=='0':                            
        row=['']*5
        row[0] = bookID
        row[1] = placename
        row[2] = guest
        row[3] = eventDate
        row[4] = availability
        
        if bookID == '':
            msg = '';
            if bookID == '':
                msg += 'Book ID' if len(msg)==0 else ',Book ID'
            msg = msg + ' cannot be empty!';
            return render_template('form_booking.html',message=msg,status='0',row=row)
        else:
            if check_bookID(bookID):
                row[0] = ''
                flash('Book ID already exist!')                
                return render_template('form_booking.html',message='Booking ID '+bookID+' already exist!',status='0',row=row)

            else:        
                insert_booking(bookID, guest, placename, eventDate, availability)        
                return redirect('/list_booking') 
             
          
    if request.method=="POST" and request.form['status']=='1':
        update_booking(bookID, guest, placename, eventDate, availability)
        return redirect('/list_booking')
             
    
@app.route('/')
def home():
    if not session.get('logged_in'):
        return render_template('loginwed.html')
    else:
        return render_template('home2.html')
 
@app.route('/login', methods=['POST'])
def dologin():
    if checklogin(request.form['username'],request.form['password']):
        session['logged_in'] = True
        return render_template('home2.html')
    else:
        flash('wrong password!')
        return render_template('loginwed.html',message='Invalid Username or Password!')
        # return redirect('/')

@app.route('/logout')
def logout():
    session['logged_in'] = False
    return home()

 
# start the server using the run() method
if __name__ == "__main__":
     app.secret_key = "!mzo53678912489"
     app.run(debug=True,host='0.0.0.0', port=5000)
