<?PHP
$custID = $_GET['custID'];
include ('001link_db2.php'); 
$query = "delete from wedding_planner where custID = '$custID'";
$result = mysqli_query($conn,$query);

if ($result==TRUE)
{	echo "record successfully Deleted";
    header("location:009editanddelete.php");
 }
if ($result==FALSE) 
{echo "record unsuccessfully Deleted";
  header("location:009editanddelete.php");}
mysqli_close($conn);
?>