<html>
<head>
<title>Search Result </title>
<link rel="stylesheet" type="text/css" href="../menu/pro_dropdown_3/pro_dropdown_3.css" />
<script src="../menu/pro_dropdown_3/stuHover.js" type="text/javascript"></script>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   
</head>
<style>
body {
  background-image: url('weding.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;
}

</style>
<body>
<center>
<h1> Search Result </h1>
</center>
<?php

$searchtype=$_POST['searchtype'];
$searchterm=$_POST['searchterm'];
$searchterm= trim($searchterm);

if (!$searchtype || !$searchterm)
{
	echo ' Please Enter your search. Please enter again.';
	exit;
}

include ('001link_db2.php');
$query = "select * from v_detail where ".$searchtype." like '%".$searchterm."%'";
$result = mysqli_query($conn,$query);
$num_results = mysqli_num_rows($result);
echo "<center>";
echo '<p>Data founded: '.$num_results.'</p>';
?>
<div class="container">
<P><strong><center> Wedding List</strong></center>
<style>
table {
  width:100%;
}
table, th, td {
  border: 2px solid black;
  border-collapse: collapse;
  background-color: #dbd2cc;
  font-family:times new roman; 
  
}
th, td {
  padding: 15px;
  text-align: center;
  background-color: white;

} </style>  
<table border="1" width="849" align="center" cellspacing="2" cellpadding="2">
<tr>
<td align="center" bgcolor="#FFCC00"><strong>Customer ID</strong></td>
<td align="center" bgcolor="#FFCC00"><strong>Customer Name</strong></td>
<td align="center" bgcolor="#FFCC00"><strong>Customer Phone</strong></td>
<td align="center" bgcolor="#FFCC00"><strong>Customer Email</strong></td> 
<td align="center" bgcolor="#FFCC00"><strong>Booking ID</strong></td> 
<td align="center" bgcolor="#FFCC00"><strong>Event Date</strong></td> 
<td align="center" bgcolor="#FFCC00"><strong>Place name</strong></td> 
<td align="center" bgcolor="#FFCC00"><strong>Guest</strong></td> 
<td align="center" bgcolor="#FFCC00"><strong>Customer Budget</strong></td> 
<td align="center" bgcolor="#FFCC00"><strong>Total Cost</strong></td> 

</tr>
<?PHP

for ($i=0; $i <$num_results; $i++)
{
 $row = mysqli_fetch_array($result);
echo "<tr>";
 echo "<td>" .$row["custID"]. "</td>";
 echo "<td>" .$row["custname"].  "</td>";
 echo "<td>" .$row["custPhone"]."</td>";
 echo "<td>" .$row["custEmail"]."</td>";
 echo "<td>" .$row["bookID"]."</td>";
 echo "<td>" .$row["eventDate"]."</td>";
 echo "<td>" .$row["placename"]."</td>";
 echo "<td>" .$row["guest"]."</td>";
 echo "<td>" .$row["custBudget"]."</td>";
 echo "<td>" .$row["totalcost"]."</td>";
}
echo "</table>";
echo "<center>";
echo "<br>";
 ?>
 <ul class="pagination">
  <li class="page-item"><a class="page-link" href="data_wedding_planner.php">Wedding Planner</a></li>
  <li class="page-item"><a class="page-link" href="data_booking.php">Booking</a></li>
  <li class="page-item"><a class="page-link" href="data_detail.php">Detail</a></li>
  <li class="page-item"><a class="page-link" href="009editanddelete.php">Edit & Delete</a></li>
  <li class="page-item"><a class="page-link" href="v_detail.php"> View Detail</a></li>
  <li class="page-item active"><a class="page-link" href="014frm_search.php"> Search</a></li>
  </ul>
  
  <center>
    <a name="SUBMIT" type="SUBMIT" href="welcome_admin.php"  class="btn btn-default">BACK </a> 
	</center>
<br>
<br>
</body>
</html>
