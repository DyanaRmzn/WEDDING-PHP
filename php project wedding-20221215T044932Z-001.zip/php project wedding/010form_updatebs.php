<!DOCTYPE html> 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Update Wedding</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
<?PHP
include ('001link_db2.php'); 
$custID=$_GET['custID'];
$query="SELECT * FROM wedding_planner WHERE custID='$custID'";
$result=mysqli_query($conn,$query);
$num= mysqli_num_rows($result);

$i=0;
while ($i < $num) {
$show=mysqli_fetch_assoc($result);
$custID=$show['custID'];
$custname=$show['custname'];
$custBudget=$show['custBudget'];
$custPhone=$show['custPhone'];
$custEmail=$show['custEmail'];
?>
<div class="container">
<form action="011pros_update.php" method="post">
  <div class="form-group">
    <label for="custID">Cust ID:</label>
    <input type="text" class="form-control" name="ud_custID" id="ud_custID" value="<?php echo $custID; ?>" />
  </div>
  <div class="form-group">
    <label for="custname">Cust Name:</label>
    <input type="text" class="form-control" name="ud_custname" id="ud_custname"  value="<?php echo $custname; ?>" />
  </div>
  
  
  <div class="form-group">
    <label for="custBudget">Cust Budget:</label>
    <input type="text" class="form-control" name="ud_custBudget" id="ud_custBudget"  value="<?php echo $custBudget; ?>" />
  </div>
  
  <div class="form-group">
    <label for="custPhone">Cust Phone:</label>
    <input type="text" class="form-control" name="ud_custPhone" id="ud_custPhone"  value="<?php echo $custPhone; ?>" />
  </div>
  
  <div class="form-group">
    <label for="custEmail">Cust Email:</label>
    <input type="text" class="form-control" name="ud_custEmail" id="ud_custEmail"  value="<?php echo $custEmail; ?>" />
  </div>
 

  <button  name="SUBMIT" type="SUBMIT" class="btn btn-default">SUBMIT</button>
</form>

<?PHP
++$i;
}
?>
</body>
</html>