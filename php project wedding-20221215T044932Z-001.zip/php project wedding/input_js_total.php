<!DOCTYPE html>
<html>
<head>
<title>Registration Form</title>
</head>
<body>
<?php 
include ('001link_db2.php'); 
$custID = $_POST['custID'];
$bookID = $_POST['bookID'];
$foodcost = $_POST['foodcost'];
$preparecost = $_POST['preparecost'];
$totalcost = $_POST['totalcost'];
$query ="insert into detail (custID, bookID, foodcost, preparecost, totalcost)
values('$custID','$bookID','$foodcost','$preparecost','$totalcost')";
if (mysqli_query($conn, $query)) {
  echo "Customer ID :".$custID."<br>";
  echo "Book ID :".$bookID."<br>";
  echo "Food cost :".$foodcost."<br>";
  echo "Prepare cost :".$preparecost."<br>";
  echo "Total cost :".$totalcost."<br>";
  
    echo "New record created successfully";
	header("location: data_detail.php");
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?> 
</body>
</html>