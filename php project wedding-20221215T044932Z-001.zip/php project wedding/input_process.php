<!DOCTYPE html>
<html>
<head>
<title>Registration Form</title>
</head>
<body>
<?php 
include ('001link_db2.php'); 
$custID = $_POST['custID'];
$custname = $_POST['custname'];
$custBudget = $_POST['custBudget'];
$custPhone = $_POST['custPhone'];
$custEmail = $_POST['custEmail'];
$query ="insert into wedding_planner (custID, custname, custBudget, custPhone, custEmail)
values ('$custID','$custname','$custBudget', '$custPhone', '$custEmail')";
if (mysqli_query($conn, $query)) {
	//echo "<center><p><img src=\"$target_file\" width=\"190\" height=\"200\"><p>";
  echo "Customer Name :".$custname."<br>";
  echo "Customer Budget (RM) :".$custBudget."<br>";
  echo "Cust Phone :".$custPhone."<br>";
  echo "Cust Email :".$custEmail."<br>";
  
    echo "New record created successfully";
	header("location: data_wedding_planner.php");
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?> 
</body>
</html>
