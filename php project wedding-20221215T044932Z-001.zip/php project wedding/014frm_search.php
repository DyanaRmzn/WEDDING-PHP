<html>
<head>
<title> Search </title>
<link rel="stylesheet" type="text/css" href="../menu/pro_dropdown_3/pro_dropdown_3.css" />
<script src="../menu/pro_dropdown_3/stuHover.js" type="text/javascript"></script>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   
</head>
<link rel="stylesheet" media="screen" href = "/static/css/bootstrap.min.css">
<style>
body {
  background-image: url('weding.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;
}

</style>
<body>
<h1 align="center"> Searching </h1>

<form  action="015proc_search2.php" method="post" >
  <div align="center"><span class="style1">Search for</span>:<br/>
    <Select NAME="searchtype">
         <Option VALUE="custID">Customer ID</option>
         <Option VALUE="custname">Customer Name</option>
		 <Option VALUE="custname">Customer Phone</option>
		 <Option VALUE="bookID"> Booking ID</option>
         <Option VALUE="placename">Place Name</option>
	
    </Select>
    <br />
Enter Search Term:<br />
<input name="searchterm" type="text" >
<br />
<input type="submit" name="search" value="Search" >
  </div>
</form>
<ul class="pagination">
  <li class="page-item"><a class="page-link" href="data_wedding_planner.php">Wedding Planner</a></li>
  <li class="page-item"><a class="page-link" href="data_booking.php">Booking</a></li>
  <li class="page-item"><a class="page-link" href="data_detail.php">Detail</a></li>
  <li class="page-item"><a class="page-link" href="009editanddelete.php">Edit & Delete</a></li>
  <li class="page-item"><a class="page-link" href="v_detail.php"> View Detail</a></li>
  <li class="page-item active"><a class="page-link" href="014frm_search.php"> Search</a></li>
  </ul>
<center>
    <a name="SUBMIT" type="SUBMIT" href="welcome_admin.php"  class="btn btn-default">BACK </a> 
	</center>
<br>
</body>
</html>
