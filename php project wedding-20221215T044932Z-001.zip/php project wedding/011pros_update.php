<?PHP include ('001link_db2.php'); 
$ud_custID=$_POST['ud_custID'];
$ud_custname=$_POST['ud_custname'];
$ud_custBudget=$_POST['ud_custBudget'];
$ud_custPhone=$_POST['ud_custPhone'];
$ud_custEmail=$_POST['ud_custEmail'];

$query="UPDATE wedding_planner SET custname='$ud_custname', custBudget='$ud_custBudget', custPhone='$ud_custPhone',
custEmail='$ud_custEmail'
WHERE custID='$ud_custID'";
mysqli_query($conn,$query);
header("location:009editanddelete.php");
mysqli_close($conn);
?>