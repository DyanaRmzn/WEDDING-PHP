<html>
<head>
<title>Admin Welcome </title>
<link rel="stylesheet" type="text/css" href="../menu/pro_dropdown_3/pro_dropdown_3.css" />
<script src="../menu/pro_dropdown_3/stuHover.js" type="text/javascript"></script>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   
</head>
</head>
<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login_admin.php");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome Page Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">    
</head>
<body>
    <<header>
    <div class="wrapper">
        <div class="logo">
            <img src="lo.png" alt="logo" style="width:100px;height:100px;">
        </div>
<ul class="nav-area">
<br>
<LI><A HREF="data_wedding_planner.php" TARGET="RightFrame">Customer Data</A></LI>
<LI><A HREF="data_booking.php" TARGET="RightFrame">View Booking</A></LI>
<LI><A HREF="data_detail.php" TARGET="RightFrame">Wedding Detail</A></LI>
<LI><A HREF="new_form_wedding.html" TARGET="RightFrame">Insert New </A></LI>
<LI><A HREF="new_form_totalcost.html" TARGET="RightFrame">Calculate Cost</A></LI>
<LI><A HREF="009editanddelete.php" TARGET="RightFrame">Edit & Delete</A></LI>
<LI><A HREF="014frm_search.php" TARGET="RightFrame">Searching</A></LI>

</ul>
</div>
<div class="welcome-text">
        <h1>
  <h1 style="color:Tomato">WEDDING PLANNER </span></h1>

<p style="color:white"; > PLANNING FOR BETTER FUTURE. </p>

<a style="color:black"; href="logout.php" class="btn btn-danger">Logout</a> 
    

    </div>
</header>

</body>
</html>
 
